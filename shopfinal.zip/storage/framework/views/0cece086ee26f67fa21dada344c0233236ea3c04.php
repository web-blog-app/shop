<footer class="footer container">
    <div class="footer-description">
        © 2019 <?php echo e(setting('site.my_company')); ?> - надежное оборудование, проверенный инструмент
    </div>
    <div class="footer-address-container">
        <div class="footer-address">
            <?php echo e(setting('site.my_addr')); ?>

        </div>
        <div class="footer-phones">
            <?php echo e(setting('site.my_phone')); ?>

        </div>
    </div>
</footer>
