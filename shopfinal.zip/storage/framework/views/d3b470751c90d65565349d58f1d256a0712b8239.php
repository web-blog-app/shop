<div class="breadcrumbs">
    <div class="breadcrumbs-container container">
        <div>
            <?php echo e($slot); ?>

        </div>
    </div>
</div> <!-- end breadcrumbs -->
