<div class="breadcrumbs">
    <div class="breadcrumbs-container container">
        <div>
            {{ $slot }}
        </div>
    </div>
</div> <!-- end breadcrumbs -->
