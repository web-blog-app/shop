<footer class="footer container">
    <div class="footer-description">
        © 2019 {{setting('site.my_company')}} - надежное оборудование, проверенный инструмент
    </div>
    <div class="footer-address-container">
        <div class="footer-address">
            {{setting('site.my_addr')}}
        </div>
        <div class="footer-phones">
            {{setting('site.my_phone')}}
        </div>
    </div>
</footer>
